﻿using Microsoft.AspNetCore.Mvc;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using System.Threading.Tasks;
using Messages.Models;
using System.Web;

namespace Messages.Controllers
{
    public class MessageController : Controller
    {

        private readonly IConfiguration _configuration;

        public MessageController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // Muestra el formulario para enviar el mensaje
        public IActionResult SendMessage()
        {
            return View();
        }

        // Maneja el envío del mensaje
        [HttpPost]
        public async Task<IActionResult> SendMessage(Message message)
        {
            if (ModelState.IsValid)
            {
                var accountSid = _configuration["Twilio:AccountSid"];
                var authToken = _configuration["Twilio:AuthToken"];
                TwilioClient.Init(accountSid, authToken);

                try
                {
                    if (message.ServiceType == MessageServiceType.SMS)
                    {
                        // Enviar SMS
                        var smsMessage = await MessageResource.CreateAsync(
                            body: message.MessageText,
                            from: new PhoneNumber(_configuration["Twilio:FromPhoneNumber"]),
                            to: new PhoneNumber(message.PhoneNumber)
                        );
                    }
                    else if (message.ServiceType == MessageServiceType.WhatsApp)
                    {
                        // Enviar WhatsApp
                        var whatsappMessage = await MessageResource.CreateAsync(
                            body: message.MessageText,
                            from: new PhoneNumber($"whatsapp:{_configuration["Twilio:WhatsAppFromPhoneNumber"]}"),
                            to: new PhoneNumber($"whatsapp:{message.PhoneNumber}")
                        );
                    }

                    TempData["Success"] = "Mensaje enviado exitosamente";
                    return RedirectToAction("SendMessage");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Error al enviar el mensaje: {ex.Message}");
                }
            }

            return View(message);
        }





        /*
        // Método para redirigir al enlace de WhatsApp Web
        [HttpPost]
        public IActionResult SendWhatsAppMessage(string phoneNumber, string messageBody)
        {
            // Asegurarse de que el número esté en formato internacional correcto (sin +, sin espacios)
            string formattedNumber = phoneNumber.Replace("+", "").Replace(" ", "");

            // Codificar el mensaje en URL
            string encodedMessage = HttpUtility.UrlEncode(messageBody);

            // Construir la URL de WhatsApp Web
            string whatsappUrl = $"https://wa.me/{formattedNumber}?text={encodedMessage}";

            // Redirigir al usuario a WhatsApp Web con el mensaje
            return Redirect(whatsappUrl);
        }

        // Acción para mostrar el formulario de envío
        public IActionResult SendMessage()
        {
            return View();
        }*/
    }
}
