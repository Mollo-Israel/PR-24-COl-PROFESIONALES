﻿namespace Messages.Models
{
    public class ScheduledMessage
    {
        public int Id { get; set; }
        public string PhoneNumber { get; set; }
        public string MessageBody { get; set; }
        public DateTime ScheduledTime { get; set; }
        public bool IsSent { get; set; }
    }
}
