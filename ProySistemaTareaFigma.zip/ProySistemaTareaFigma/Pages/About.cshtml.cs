using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProySistemas.Pages
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
